InsureEasy Insurance

Files:
index.html
style.css
script.js

Open index.html in a browser.